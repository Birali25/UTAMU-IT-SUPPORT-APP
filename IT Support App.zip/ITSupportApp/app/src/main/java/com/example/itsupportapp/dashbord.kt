package com.example.itsupportapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DashboardActivity : AppCompatActivity() {

    private lateinit var btnViewIssue: Button
    private lateinit var btnReportIssue: Button
    private lateinit var btnCloseWorkOrder: Button
    private lateinit var btnNotification: Button

    private lateinit var txtPendingIssues: TextView
    private lateinit var txtResolvedIssues: TextView

    // Sample data for demonstration
    private var pendingCount = 5
    private var resolvedCount = 12

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashbord)

        // Initialize buttons
        btnViewIssue = findViewById(R.id.btnViewIssue)
        btnReportIssue = findViewById(R.id.btnReportIssue)
        btnCloseWorkOrder = findViewById(R.id.btnCloseWorkOrder)
        btnNotification = findViewById(R.id.btnNotification)

        // Initialize TextViews
        txtPendingIssues = findViewById(R.id.txtPendingIssues)
        txtResolvedIssues = findViewById(R.id.txtResolvedIssues)

        // Set initial counts
        txtPendingIssues.text = pendingCount.toString()
        txtResolvedIssues.text = resolvedCount.toString()

        // Handle button clicks
        btnViewIssue.setOnClickListener {
            Toast.makeText(this, "View Issue clicked", Toast.LENGTH_SHORT).show()
            // TODO: Navigate to View Issue screen
        }

        btnReportIssue.setOnClickListener {
            // Navigate to Report Issue Activity
            val intent = Intent(this, ReportIssueActivity::class.java)
            startActivity(intent)
        }

        btnCloseWorkOrder.setOnClickListener {
            // Navigate to Close Work Order Activity
            val intent = Intent(this, CloseWorkOrderActivity::class.java)
            startActivity(intent)
        }

        btnNotification.setOnClickListener {
            Toast.makeText(this, "Notification clicked", Toast.LENGTH_SHORT).show()
            // TODO: Navigate to Notification screen
        }
    }
}
