package com.example.itsupportapp

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ReportIssueActivity : AppCompatActivity() {

    private lateinit var edtIssueTitle: EditText
    private lateinit var edtIssueDescription: EditText
    private lateinit var spinnerDepartment: Spinner
    private lateinit var spinnerPriority: Spinner
    private lateinit var imgPhotoPreview: ImageView
    private lateinit var btnCapturePhoto: Button
    private lateinit var btnShareScreenshot: Button
    private lateinit var btnSubmitIssue: Button

    private val CAMERA_REQUEST_CODE = 1001
    private var capturedPhoto: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reportissue)

        // Initialize views
        edtIssueTitle = findViewById(R.id.edtIssueTitle)
        edtIssueDescription = findViewById(R.id.edtIssueDescription)
        spinnerDepartment = findViewById(R.id.spinnerDepartment)
        spinnerPriority = findViewById(R.id.spinnerPriority)
        imgPhotoPreview = findViewById(R.id.imgPhotoPreview)
        btnCapturePhoto = findViewById(R.id.btnCapturePhoto)
        btnShareScreenshot = findViewById(R.id.btnShareScreenshot)
        btnSubmitIssue = findViewById(R.id.btnSubmitIssue)

        // Setup spinners
        val departments = listOf("Engineering", "HR", "QC", "QA", "Warehouse", "Production")
        val priorities = listOf("High", "Moderate", "Low")

        spinnerDepartment.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, departments).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinnerPriority.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, priorities).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        // Capture photo
        btnCapturePhoto.setOnClickListener {
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE)
        }

        // Share screenshot (simple simulation)
        btnShareScreenshot.setOnClickListener {
            val rootView = window.decorView.rootView
            val bitmap = Bitmap.createBitmap(rootView.width, rootView.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            rootView.draw(canvas)

            Toast.makeText(this, "Screenshot captured and ready to share (simulated)", Toast.LENGTH_SHORT).show()
        }

        // Submit issue
        btnSubmitIssue.setOnClickListener {
            val title = edtIssueTitle.text.toString().trim()
            val description = edtIssueDescription.text.toString().trim()
            val department = spinnerDepartment.selectedItem.toString()
            val priority = spinnerPriority.selectedItem.toString()

            if (title.isEmpty() || description.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            } else {
                val photoStatus = if (capturedPhoto != null) "Yes" else "No"
                Toast.makeText(
                    this,
                    "Issue Submitted!\nTitle: $title\nDept: $department\nPriority: $priority\nPhoto attached: $photoStatus",
                    Toast.LENGTH_LONG
                ).show()

                // Reset fields
                edtIssueTitle.text.clear()
                edtIssueDescription.text.clear()
                spinnerDepartment.setSelection(0)
                spinnerPriority.setSelection(0)
                imgPhotoPreview.setImageBitmap(null)
                capturedPhoto = null
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            capturedPhoto = data?.extras?.get("data") as Bitmap
            imgPhotoPreview.setImageBitmap(capturedPhoto)
        }
    }
}
