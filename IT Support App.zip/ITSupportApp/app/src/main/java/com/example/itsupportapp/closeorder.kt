package com.example.itsupportapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class CloseWorkOrderActivity : AppCompatActivity() {

    private lateinit var edtRequestNumber: EditText
    private lateinit var spinnerStatus: Spinner
    private lateinit var edtComment: EditText
    private lateinit var btnCloseWorkOrder: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_closeorder)

        // Initialize views
        edtRequestNumber = findViewById(R.id.edtRequestNumber)
        spinnerStatus = findViewById(R.id.spinnerStatus)
        edtComment = findViewById(R.id.edtComment)
        btnCloseWorkOrder = findViewById(R.id.btnCloseWorkOrder)

        // Status options
        val statusOptions = listOf("Complete", "In Progress")
        spinnerStatus.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            statusOptions
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        // Close Work Order button click
        btnCloseWorkOrder.setOnClickListener {
            val requestNumber = edtRequestNumber.text.toString().trim()
            val status = spinnerStatus.selectedItem.toString()
            val comment = edtComment.text.toString().trim()

            if (requestNumber.isEmpty()) {
                Toast.makeText(this, "Please enter Request Order Number", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(
                    this,
                    "Request Order $requestNumber closed with status: $status\nComment: ${if (comment.isEmpty()) "None" else comment}",
                    Toast.LENGTH_LONG
                ).show()

                // Clear inputs after closing
                edtRequestNumber.text.clear()
                spinnerStatus.setSelection(0)
                edtComment.text.clear()
            }
        }
    }
}
