package com.example.itsupportapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SignUpActivity : AppCompatActivity() {

    // Declare views
    private lateinit var edtUsername: EditText
    private lateinit var edtEmail: EditText
    private lateinit var edtPassword: EditText
    private lateinit var btnSignUp: Button
    private lateinit var txtLogin: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        // Initialize views
        edtUsername = findViewById(R.id.edtUsername)
        edtEmail = findViewById(R.id.edtemail)      // fixed ID
        edtPassword = findViewById(R.id.edtPassword)
        btnSignUp = findViewById(R.id.btnsignUp)    // fixed ID
        txtLogin = findViewById(R.id.txtlogin)      // fixed ID

        // Handle Sign Up button click
        btnSignUp.setOnClickListener {
            val username = edtUsername.text.toString().trim()
            val email = edtEmail.text.toString().trim()
            val password = edtPassword.text.toString().trim()

            if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            } else {
                // Here you can add real signup logic (database/API)

                // Navigate to LoginActivity after signup
                Toast.makeText(this, "Sign Up Successful!", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish() // Close SignUpActivity
            }
        }

        // Navigate to LoginActivity when "Login" is clicked
        txtLogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish() // Close SignUpActivity
        }
    }
}
